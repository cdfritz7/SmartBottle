# ASR Smart Bottle
## Connor Fritz and Corey Karnei

This project was built with React, the deployed version is available at
[this AWS endpoint](http://smart-bottle.s3-website.us-east-2.amazonaws.com/)

Because the project uses React to inject HTML into the root document, and because
the actual deployed version is compressed, simply opening the index.html file
in the broswer will not work.

However, the javascript code is available in ./src/, the css is available in ./src/css/
and our imgs are available in ./src/imgs/. The index.html is available in ./public/
